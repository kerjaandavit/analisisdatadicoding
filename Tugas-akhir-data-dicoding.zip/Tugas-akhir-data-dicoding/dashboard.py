import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt


st.header('Tugas Akhir Analisis Data by Davit Hidayat')
st.write(
    """
    #### -----------------   Selamat datang Reviewer Dicoding!   -----------------\n 
    Nama Saya Davit Hidayat dan Saya membuat sebuah analisis data serta visualisasi data dari\n
    E-commerce Dataset untuk memenuhi tugas akhir dari analisis data dengan python.\n
    Mengenai pembahasan, pertanyaan, dan juga conclusi sudah saya jelaskan di notebook sesuai\n
    dengan template yang sudah disediakan dan diarahkan oleh team Dicoding.\n
    Jadi di dashboard ini Saya hanya menampilkan visualisasi datanya saja.\n

    """
)
col1, col2 = st.columns([2, 2])
 
with col1:
    st.header("Analisis Data 1")
    st.image("Jumlah_pelanggan.png")
 
with col2:
    st.header("Analisis Data 2")
    st.image("order_payment.png")
 



uploaded_file = st.file_uploader('Choose a CSV file')
 
if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.dataframe(df)