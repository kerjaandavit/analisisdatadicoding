# Cara Menjalankan Dashboard

* Pastikan kamu sudah menginstall streamlit, pandas di local komputermu
* Buka File dashboard.py di Text editor favorit kamu
* Jalankan file di terminal text editor, lalu tulis **streamlit run dashboard.py

# Setup environment
```
conda create --name myenv
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit
```
# Run streamlit app
```
streamlit run dashboard.py
```